
<?php $__env->startSection('content'); ?>

	<br>
	<div class="alert mycolor1" role="alert">매입</div>

	<script>
		$(function() {
			$("#text1") .datetimepicker({
				locale: "ko",
				format: "YYYY-MM-DD",
				defaultDate: moment()
			});
		});

		function select_product()
		{
			var str;
			str = form1.sel_products_id.value;	
			if (str=="")
			{
				form1.products_id.value = "";
				form1.price.value = "";
				form1.prices.value = "";
			}
			else
			{
				str = str.split("^^");
				form1.products_id.value = str[0];
				form1.price.value = str[1];
				form1.prices.value=Number(form1.price.value) * Number(form1.numi.value);
			}
		}

		function cal_prices()
		{
			form1.prices.value=Number(form1.price.value) * Number(form1.numi.value);
			form1.bigo.focus();
		}	
	</script>

	<form name="form1" method="post" action="<?php echo e(route('jangbui.update',$row->id)); ?><?php echo e($tmp); ?>">
	<?php echo csrf_field(); ?>
	<?php echo method_field('PATCH'); ?>

	<table class="table table-sm table-bordered mymargin5">
		<tr>
			<td width="20%" class="mycolor2">번호</td>
			<td width="80%" align="left"><?php echo e($row->id); ?></td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2"><font color="red">*</font> 날짜</td>
			<td width="80%" align="left">
				<div class="d-inline-flex">
					<div class="input-group input-group-sm date" id="writeday">
						<input type="text" name="writeday" size="10" value="<?php echo e($row->writeday); ?>" 
							class="form-control form-control-sm">
						<div class="input-group-text">
							<div class="input-group-addon">
								<i class="far fa-calendar-alt fa-lg"></i>
							</div>
						</div>
					</div>
				</div>
			    <?php $__errorArgs = ['writeday'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2"><font color="red">*</font> 제품명</td>
			<td width="80%" align="left">
				<div class="d-inline-flex">
					<input type="hidden" name="products_id" value="<?php echo e($row->products_id); ?>">
					<select name="sel_products_id" class="form-select form-select-sm" 
						onchange="select_product();">
						<option value="" selected>선택하세요.</option>

				<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?
					$t1="$row1->id^^$row1->price";				// 제품번호^^단가"
					$t2="$row1->name($row1->price)";			//	제품이름(단가)"
?>
					<?php if( $row->products_id == $row1->id ): ?>
						<option value="<?php echo e($t1); ?>" selected><?php echo e($t2); ?></option>
					<?php else: ?>
						<option value="<?php echo e($t1); ?>"><?php echo e($t2); ?></option>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</select>
				</div>
			    <?php $__errorArgs = ['products_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2">단가</td>
			<td width="80%" align="left">
				<div class="d-inline-flex">
					<input type="text" name="price" size="20" value="<?php echo e($row->price); ?>" 
						class="form-control form-control-sm" onChange="cal_prices();">
				</div>
			</td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2"> 수량</td>
			<td width="80%" align="left">
				<div class="d-inline-flex">
					<input type="text" name="numi" size="20" value="<?php echo e($row->numi); ?>" 
						class="form-control form-control-sm" onChange="cal_prices();">
				</div>
			</td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2"> 금액</td>
			<td width="80%" align="left">
				<div class="d-inline-flex">
					<input type="text" name="prices" size="20" value="<?php echo e($row->prices); ?>" 
						class="form-control form-control-sm" readonly>
				</div>
			</td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2"> 비고 </td>
			<td width="80%" align="left">
				<div class="d-inline-flex">
					<input type="text" name="bigo" size="20" value="<?php echo e($row->bigo); ?>" 
						class="form-control form-control-sm">
				</div>
			</td>
		</tr>
	</table>

	<div align="center">
		<input type="submit" value="저장" class="btn btn-sm mycolor1">&nbsp;
		<input type="button" value="이전화면" class="btn btn-sm mycolor1" onClick="history.back();">
	</div>

	</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\APM\Apache24\htdocs\sale\resources\views/jangbui/edit.blade.php ENDPATH**/ ?>