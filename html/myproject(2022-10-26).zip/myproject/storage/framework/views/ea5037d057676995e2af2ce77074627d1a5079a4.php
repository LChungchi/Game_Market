
<?php $__env->startSection('content'); ?>

	<br>
	<div class="alert mycolor1" role="alert">구분</div>

	<form name="form1" method="post" action="">

	<table class="table table-sm table-bordered mymargin5">
		<tr>
			<td width="20%" class="mycolor2">번호</td>
			<td width="80%" align="left"><?php echo e($row->id); ?></td>
		</tr>
		<tr>
			<td width="20%" class="mycolor2"><font color="red">*</font> 구분명</td>
			<td width="80%" align="left"><?php echo e($row->name); ?></td>
		</tr>
	</table>

	<div align="center">
		<a href="<?php echo e(route('gubun.edit', $row->id)); ?><?php echo e($tmp); ?>" class="btn btn-sm mycolor1">수정</a>
		<form action="<?php echo e(route('gubun.destroy', $row->id)); ?>">
			<?php echo csrf_field(); ?>
			<?php echo method_field('DELETE'); ?>
			<button type="submit" class="btn btn-sm mycolor1" 
				onClick="return confirm('삭제할까요 ?');">삭제</button> &nbsp;
		</form>
		<input type="button" value="이전화면" class="btn btn-sm mycolor1" onClick="history.back();">
	</div>

	</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\APM\Apache24\htdocs\sale\resources\views/gubun/show.blade.php ENDPATH**/ ?>