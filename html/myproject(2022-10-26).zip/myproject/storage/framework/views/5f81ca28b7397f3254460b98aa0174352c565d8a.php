
<?php $__env->startSection('content'); ?>

	<br>
	<div class="alert mycolor1" role="alert">구분</div>

	<script>
		function find_text()
		{
			form1.action="<?php echo e(route('gubun.index')); ?>";
			form1.submit();
		}
	</script>

	<form name="form1" action="">
	<div class="row">
		<div class="col-3" align="left">
			<div class="input-group input-group-sm">
				<span class="input-group-text">이름</span>
				<input type="text" name="text1" size="15" value="<?php echo e($text1); ?>" class="form-control" 
					onKeydown="if (event.keyCode == 13) { find_text(); }"> 
				<button class="btn mycolor1" type="button" 
					onClick="find_text();">검색</button>
			</div>
		</div>
		<div class="col-9" align="right">
			<a href="<?php echo e(route('gubun.create')); ?><?php echo e($tmp); ?>" class="btn btn-sm mycolor1">추가</a>
		</div>
	</div>
	</form>

	<table class="table table-sm table-bordered table-hover mymargin5">
		<tr class="mycolor2">
			<td width="10%">번호</td>
			<td width="90%">구분명</td>
		</tr>

		<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($row->id); ?></td>
				<td><a href="<?php echo e(route('gubun.show', $row->id)); ?><?php echo e($tmp); ?>"><?php echo e($row->name); ?></a></td>
		   </tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</table>

	<?php echo e($list->links( 'mypagination' )); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\APM\Apache24\htdocs\sale\resources\views/gubun/index.blade.php ENDPATH**/ ?>